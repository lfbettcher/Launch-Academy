const config = {
  env: process.env["NODE_ENV"] || "development"
}

export default config
