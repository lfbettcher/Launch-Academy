package com.launchacademy.petTracker.repositories;

import com.launchacademy.petTracker.models.Pet;
import java.util.List;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PetRepository extends PagingAndSortingRepository<Pet, Integer> {

  public List<Pet> findBySpeciesId(Integer speciesId);

}
