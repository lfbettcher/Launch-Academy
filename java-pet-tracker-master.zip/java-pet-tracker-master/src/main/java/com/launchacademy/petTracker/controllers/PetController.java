package com.launchacademy.petTracker.controllers;
import com.launchacademy.petTracker.models.Pet;
import com.launchacademy.petTracker.models.Specy;
import com.launchacademy.petTracker.repositories.PetRepository;
import com.launchacademy.petTracker.repositories.SpecyRepository;
import com.launchacademy.petTracker.services.SpecyService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.launchacademy.petTracker.services.SpecyService;
import org.springframework.data.domain.Pageable;

@Controller
@RequestMapping("/pets")
public class PetController {

  private PetRepository petRepository;

  @Autowired
  public PetController(PetRepository petRepository){
    this.petRepository = petRepository;
  }

  @Autowired
  private SpecyService specyService;

  @GetMapping
  public String getPets(Model model, Pageable pageable ){
    model.addAttribute("pets", petRepository.findAll(pageable));
    return "pets/index";
  }

  @GetMapping("/new")
  public String goPetForm(Model model){
    Pet pet  = new Pet();
    Specy specy = new Specy();
    model.addAttribute("pet", pet);
    return ("pets/new");
  }

//  @PostMapping
//  public String create(@ModelAttribute Pet pet) {
//    petRepository.save(pet);
//    return "redirect:/pets";
//  }

  @PostMapping
  public String create(@ModelAttribute @Valid Pet pet, BindingResult bindingResult) {

   if(bindingResult.hasErrors()){
     return "pets/new";
   }else{
    String name = pet.getSpecy().getName();
    Specy inputSpecy = this.specyService.findSpecy(name);
    pet.setSpecy(inputSpecy);
    petRepository.save(pet);
    return "redirect:/pets";}
  }

//  @GetMapping("/{id}")
//  public String showPet(@PathVariable Integer id, Model model){
//Pet pet = petRepository.findById(id).get();
//    model.addAttribute("pet",pet);
//    return "pets/show";
//  }

}