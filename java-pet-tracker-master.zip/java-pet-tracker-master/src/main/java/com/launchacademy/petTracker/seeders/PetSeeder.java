package com.launchacademy.petTracker.seeders;

import com.google.inject.internal.util.Lists;
import com.launchacademy.petTracker.models.Pet;
import com.launchacademy.petTracker.models.Specy;
import com.launchacademy.petTracker.repositories.PetRepository;
import com.launchacademy.petTracker.repositories.SpecyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;



@Component
public class PetSeeder implements CommandLineRunner {

  @Autowired
  private PetRepository petRepository;
  private SpecyRepository specyRepository;


  @Autowired
  PetSeeder(PetRepository petRepository, SpecyRepository specyRepository){
    this.petRepository = petRepository;
    this.specyRepository = specyRepository;
  }

  @Override
  public void run(String... args) throws Exception{

    Pet pet1 = new Pet();
    Pet pet2 = new Pet();
    Pet pet3 = new Pet();

    Specy specy1 = specyRepository.findById(1).get();
    Specy specy2 = specyRepository.findById(2).get();
    Specy specy3 = specyRepository.findById(3).get();

    if (Lists.newArrayList(petRepository.findAll()).size() == 0) {
      pet1.setName("Litte Dog");
      pet1.setSpecy(specy1);
      pet1.setBreed("Cute Dog");
      pet1.setAge(5);
      pet1.setNeutered(true);
      petRepository.save(pet1);

      pet2.setName("Litte Cat");
      pet1.setSpecy(specy2);
      pet2.setBreed("Cute Cat");
      pet2.setAge(5);
      pet2.setNeutered(true);
      petRepository.save(pet2);

      pet3.setName("Litte Bunny");
      pet1.setSpecy(specy3);
      pet3.setBreed("Cute Bunny");
      pet3.setAge(5);
      pet3.setNeutered(true);
      petRepository.save(pet3);
    }
  }


}
