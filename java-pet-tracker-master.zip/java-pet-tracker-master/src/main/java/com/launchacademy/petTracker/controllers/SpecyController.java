package com.launchacademy.petTracker.controllers;


import com.launchacademy.petTracker.models.Specy;
import com.launchacademy.petTracker.repositories.PetRepository;
import com.launchacademy.petTracker.repositories.SpecyRepository;
import com.launchacademy.petTracker.services.SpecyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/species")
public class SpecyController {

@Autowired
  private PetRepository petRepository;

@Autowired
private SpecyRepository specyRepository;

  @GetMapping("/{id}")
  public String getSpeciesPets(Model model, @PathVariable int id){
    Specy specy = specyRepository.findById(id).get();
    model.addAttribute("pets", petRepository.findBySpeciesId(id));
    model.addAttribute("specy", specy);
    System.out.println(specy.getName());
    return "pets/speciesIndex";
  }
}
