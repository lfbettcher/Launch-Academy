package com.launchacademy.petTracker.seeders;


import com.google.inject.internal.util.Lists;
import com.launchacademy.petTracker.models.Specy;
import com.launchacademy.petTracker.repositories.SpecyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class SpecySeeder implements CommandLineRunner {

  private SpecyRepository specyRepository;

  @Autowired
  SpecySeeder(SpecyRepository specyRepository){
    this.specyRepository = specyRepository;
  }

  @Override
  public void run(String... args) throws Exception{

    Specy specy1 = new Specy();
    Specy specy2 = new Specy();
    Specy specy3 = new Specy();

    if (Lists.newArrayList(specyRepository.findAll()).size() == 0) {
      specy1.setName("Dog");
      specyRepository.save(specy1);

      specy2.setName("Cat");
      specyRepository.save(specy2);

      specy3.setName("Bunny");
      specyRepository.save(specy3);
    }
  }


}
