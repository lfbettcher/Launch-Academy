package com.launchacademy.petTracker.repositories;

import com.launchacademy.petTracker.models.Specy;
import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SpecyRepository extends CrudRepository<Specy,Integer> {
  public Specy findByName(String name);
public List<Specy> findAllByName(String name);
}
