package com.launchacademy.petTracker.services;

import com.launchacademy.petTracker.models.Specy;
import com.launchacademy.petTracker.repositories.SpecyRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class SpecyService {

  private SpecyRepository specyRepository;

  @Autowired
  public SpecyService(SpecyRepository specyRepository){
    this.specyRepository = specyRepository;
  }

  public Specy findSpecy(String name){
List<Specy> findAllbyInput = this.specyRepository.findAllByName(name);
Specy specy = new Specy();
if(findAllbyInput.size()>0){
  specy = this.specyRepository.findByName(name);
}else{
  specy.setName(name);
  specyRepository.save(specy);
}

    return specy;
  }

}
