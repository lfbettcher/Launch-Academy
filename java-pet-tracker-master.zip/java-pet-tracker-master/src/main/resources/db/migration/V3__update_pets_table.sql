ALTER TABLE pets
DROP COLUMN species,
ADD COLUMN species_id int REFERENCES species(id);